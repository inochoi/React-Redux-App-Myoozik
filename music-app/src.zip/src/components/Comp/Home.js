import React from 'react';

const Home = () => {
    return ( 
        <h1>This is my Home page.</h1>
     );
}
 
export default Home;