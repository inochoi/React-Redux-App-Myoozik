import React from 'react';

const About = () => {
    return ( 
        <h1>This is my About page.</h1>
     );
}
 
export default About;